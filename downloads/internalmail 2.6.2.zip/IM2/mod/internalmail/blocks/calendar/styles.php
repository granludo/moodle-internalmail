.block_calendar_upcoming .event .date {
    text-align:right;
    font-size:0.8em;
}
