<?PHP

echo "YOUR CODE GOES HERE";

?>