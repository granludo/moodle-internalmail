<?PHP // $Id: version.php,v 1.34.2.1 2004/08/24 10:13:38 gustav_delius Exp $

////////////////////////////////////////////////////////////////////////////////
//  Code fragment to define the module version etc.
//  This fragment is called by /admin/index.php
////////////////////////////////////////////////////////////////////////////////

$module->version  = 2006060600;
$module->requires = 2005041300;  // Requires this Moodle version
$module->cron     = 60;

?>
